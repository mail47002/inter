@extends('frontend.layouts.default')

@include('frontend.layouts.navigation')

@section('title')Mokėjimas atšauktas - @stop

@section('content')
	<div class="page-header">
		<h1>Mokėjimas atšauktas!</h1>
	</div>
	
	Mokėjimas buvo atšauktas. Kreditai nesuteikti.
@stop