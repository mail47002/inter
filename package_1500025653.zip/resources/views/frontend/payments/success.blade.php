@extends('frontend.layouts.default')

@include('frontend.layouts.navigation')

@section('title')Apmokėta - @stop

@section('content')
	<div class="page-header">
		<h1>Mokėjimas priimtas!</h1>
	</div>
	
	Jūs sėkmingai atlikote mokėjimą, kreditai suteikti.
@stop