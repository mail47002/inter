@extends('frontend.layouts.default')

@include('frontend.layouts.navigation')

@section('title')Privatūs rezultatai - @stop

@section('content')
	<div class="alert alert-warning">
		<h4>Privatūs rezultatai!</h4>

		Šios anketos rezultatai viešai nepublikuojami.
	</div>
@stop