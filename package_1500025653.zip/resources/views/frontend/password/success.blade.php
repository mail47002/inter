@extends('frontend.layouts.default')

@include('frontend.layouts.navigation')

@section('title')Slaptažodis pakeistas - @stop

@section('content')
	<div class="page-header">
		<h1>
			Slaptažodis pakeistas
		</h1>
	</div>

	Jūsų slaptažodis sėkmingai atkurtas, dabar galite prisijungti su naujuoju slaptažodžiu.
@stop