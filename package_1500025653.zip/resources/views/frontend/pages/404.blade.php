@extends('frontend.layouts.default')

@section('title')Puslapis nerastas - @stop

@section('content')
	<h1>Puslapis nerastas</h1>
@stop