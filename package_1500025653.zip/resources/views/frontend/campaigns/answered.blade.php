@extends('frontend.layouts.default')

@include('frontend.layouts.navigation')

@section('title')Anketa užpildyta - @stop

@section('content')
	<div class="alert alert-success">
		<h4>Anketa užpildyta!</h4>

		Jūs sėkmingai užpildėte šią anketą.
	</div>
@stop