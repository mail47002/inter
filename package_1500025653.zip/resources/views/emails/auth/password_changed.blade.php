<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2>Pakeistas slaptažodis</h2>

		<div>
			<p>
				Sveiki, mūsų sistemoje buvo atnaujitnas jūsų paskyros slaptažodis. Siunčiame jums naujus prisijungimo duomenis.
			</p>

			<p>
				El. paštas prisijungimui: {{ $email }}<br>
				Slaptažodis: {{ $password }}
			</p>
		</div>
	</body>
</html>