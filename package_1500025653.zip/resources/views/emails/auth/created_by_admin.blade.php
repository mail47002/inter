<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2>Prisijungimo duomenys</h2>

		<div>
			<p>
				Sveiki, administratorius sukūrė jums vartotoją mūsų sistemoje. Siunčiame jums prisijungimo duomenis.
			</p>

			<p>
				El. paštas prisijungimui: {{ $email }}<br>
				Slaptažodis: {{ $password }}
			</p>
		</div>
	</body>
</html>