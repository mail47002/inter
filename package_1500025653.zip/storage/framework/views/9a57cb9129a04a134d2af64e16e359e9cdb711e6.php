<?php echo $__env->make('frontend.layouts.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('title'); ?>Anketos „<?php echo e($entry->title); ?>“ nustatymai - <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<?php echo e(Form::open( ['route' => ['campaigns.update', $entry->id], 'class' => 'form-horizontal', 'files' => true] )); ?>

		<div class="page-header">
			<h1>
				<?php echo e($entry->title); ?>

				<br class="visible-xs visible-sm">
				<small>Anketos nustatymai</small>
				
				<div class="pull-right hidden-sm hidden-xs">
					<button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Išsaugoti duomenis</button>
				</div>
			</h1>

			<div class="visible-xs visible-sm">
				<button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Išsaugoti duomenis</button>
			</div>
		</div>

		<?php echo $__env->make('frontend.campaigns.tabs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		<?php if(Session::get('updated')): ?>
			<div class="alert alert-success">
				Anketa sėkmingai atnaujinta.
			</div>
		<?php endif; ?>

		<div class="row">
			<div class="col-sm-6">
				<p class="lead">Bendrieji duomenys</p>

				<div class="form-group <?php echo e(( $errors->first('title') ? 'has-error' : NULL)); ?>">
					<?php echo e(Form::label('title', 'Pavadinimas', [ 'class' => 'col-sm-3 control-label'])); ?>


					<div class="col-sm-9">
						<?php echo e(Form::text('title', $entry->title, [ 'class' => 'form-control', 'placeholder' => 'Anketos pavadinimas'])); ?>


						<?php echo e($errors->first('title', '<label class="control-label">:message</label>')); ?>

					</div>
				</div>

				<div class="form-group <?php echo e(( $errors->first('description') ? 'has-error' : NULL)); ?>">
					<?php echo e(Form::label('description', 'Aprašymas', [ 'class' => 'col-sm-3 control-label'])); ?>


					<div class="col-sm-9">
						<?php echo e(Form::textarea('description', $entry->description, [ 'class' => 'form-control', 'placeholder' => 'Anketos aprašymas'])); ?>


						<?php echo e($errors->first('description', '<label class="control-label">:message</label>')); ?>

					</div>
				</div>

				<div class="form-group <?php echo e(( $errors->first('tags') ? 'has-error' : NULL)); ?>">
					<?php echo e(Form::label('tags', 'Žymės', [ 'class' => 'col-sm-3 control-label'])); ?>


					<div class="col-sm-9">
						<?php echo e(Form::text('tags', $entry->tags, [ 'class' => 'form-control', 'placeholder' => 'Anketos žymės'])); ?>


						<span class="label label-info">Žymes atskirkite tarpais.</span>
						
						<?php echo e($errors->first('tags', '<br><label class="control-label">:message</label>')); ?>

					</div>
				</div>

				<div class="form-group <?php echo e(( $errors->first('public') ? 'has-error' : NULL)); ?>">
					<div class="col-sm-9 col-sm-offset-3">
						<div class="checkbox">
							<label>
								<?php echo e(Form::checkbox('public', 1, $entry->public)); ?> Vieša, gali rasti bet kas
							</label>
						</div>

						<?php echo e($errors->first('public', '<label class="control-label">:message</label>')); ?>

					</div>
				</div>

				<div class="form-group <?php echo e(( $errors->first('active') ? 'has-error' : NULL)); ?>" id="activator">
					<div class="col-sm-9 col-sm-offset-3">
						<div class="checkbox">
							<label>
								<?php echo e(Form::checkbox('active', 1, $entry->active)); ?> Aktyvi

								<?php if($entry->active == 1): ?>
									<span class="text-success"><strong>Dabar anketa yra aktyvi</strong></span>
								<?php else: ?>
									<span class="text-danger"><strong>Dabar anketa yra neaktyvi</strong></span>
								<?php endif; ?>
							</label>
						</div>

						<?php echo e($errors->first('active', '<label class="control-label">:message</label>')); ?>

					</div>
				</div>

				<div class="form-group <?php echo e(( $errors->first('respondents') ? 'has-error' : NULL)); ?>">
					<div class="col-sm-9 col-sm-offset-3">
						<hr>
						<div class="checkbox">
							<label>
								<?php echo e(Form::checkbox('respondents', 1, $entry->respondents)); ?> Rodyti rezultatus respondentams
							</label>
						</div>

						<?php echo e($errors->first('respondents', '<label class="control-label">:message</label>')); ?>

					</div>
				</div>

				<div class="form-group <?php echo e(( $errors->first('send_email') ? 'has-error' : NULL)); ?>">
					<div class="col-sm-9 col-sm-offset-3">
						<div class="checkbox">
							<label>
								<?php echo e(Form::checkbox('send_email', 1, $entry->send_email)); ?> Kiekvieną atsakymą siųsti man el. paštu
							</label>
						</div>

						<?php echo e($errors->first('send_email', '<label class="control-label">:message</label>')); ?>

					</div>
				</div>

				<div class="form-group <?php echo e(( $errors->first('same_computer') ? 'has-error' : NULL)); ?>">
					<div class="col-sm-9 col-sm-offset-3">
						<div class="checkbox">
							<label>
								<?php echo e(Form::checkbox('same_computer', 1, $entry->same_computer)); ?> Leisti atsakyti kelis kartus iš vieno kompiuterio
							</label>
						</div>

						<?php echo e($errors->first('same_computer', '<label class="control-label">:message</label>')); ?>

					</div>
				</div>
			</div>

			<div class="col-sm-6">
				<hr class="visible-xs visible-sm">

				<?php if($entry->active): ?>
					<div class="well">
						<p class="lead">Tiesioginė nuoroda į anketą</p>

						<p>
							<a href="<?php echo e(route('campaigns.answer', $entry->id)); ?>" target="_blank"><?php echo e(route('campaigns.answer', $entry->id)); ?></a>
						</p>

						<p><em>Šią nuorodą galite nusikopijuoti ir pasiųsti respondentams el. paštu, skype, patalpinti forumuose.</em></p>
					</div>
					
					<div class="alert alert-<?php echo e(( $errors->first('respondents') ? 'danger' : 'warning')); ?>">
						<p class="lead">Reklamuokite anketą</p>
						
						<?php if($entry->public): ?>
							<p>
								Jūs turite <strong><?php echo e($auth_user->credits()->sum('credits') - $auth_user->campaigns()->where('advertise_credits', '>', 0)->sum('advertise_credits')); ?></strong> nepanaudotų kreditų už kuriuos galite reklamuoti anketą. 
								Šios anketos vieno reklamuojamo atsakymo kaina <strong><?php echo e($entry->questions()->count() * 2); ?></strong>. 
								Įveskite reklamuojamų atsakymų kiekį kurį norėtumėte gauti šios anketos reklamos metu.
							</p>
							
							<p></p>
							
							<div class="form-inline">
								<?php echo e(Form::text('advertise_results', $entry->advertise_results, [ 'class' => 'form-control', 'placeholder' => 'Atsakymų kiekis'])); ?>


								<button type="submit" class="btn btn-default">Reklamuoti</button>
							</div>

							<?php echo e($errors->first('advertise_results', '<label class="label label-danger">:message</label>')); ?>


							<div class="clearfix"></div>

							<?php if($entry->used_results): ?>
								<hr>

								<p>
									Gavote reklamuotų atsakymų: <strong><?php echo e($entry->used_results); ?></strong><br>
									Panaudota kreditų: <strong><?php echo e($entry->used_credits); ?></strong>
								</p>
							<?php endif; ?>
						<?php else: ?>
							<p>
								Jei norite reklamuoti anketą, padarykite ją viešą.
							</p>
						<?php endif; ?>
					</div>
				<?php endif; ?>

				<hr class="visible-xs visible-sm">

				<p class="lead">Įkelkite paveikslėlį</p>

				<div class="form-group <?php echo e(( $errors->first('photo') ? 'has-error' : NULL)); ?>">
					<div class="col-sm-3">
						<?php if( ! empty($entry->photo)): ?>
							<p>
								<img src="<?php echo e(asset($entry->photo)); ?>" alt="Anketos paveikslėlis" class="img-thumbnail" style="width: 124px;">
							</p>
						<?php endif; ?>
					</div>

					<div class="col-sm-9">
						<p>
							<strong>Pasirinkite naują</strong>
						</p>

						<p>
							<?php echo e(Form::file('photo', [ 'class' => 'form-control ', 'placeholder' => 'Anketos paveikslėlis'])); ?>

							
							<span class="label label-info">Bus rodomas po anketos aprašymu.</span>

							<?php echo e($errors->first('photo', '<br><label class="control-label">:message</label>')); ?>

						</p>
					</div>
				</div>

				<hr>

				<p class="lead">Vaizdo įrašas</p>

				<div class="form-group <?php echo e(( $errors->first('video') ? 'has-error' : NULL)); ?>">
					<div class="col-sm-12">
						<?php echo e(Form::text('video', $entry->video, [ 'class' => 'form-control', 'placeholder' => 'http://'])); ?>


						<span class="label label-info"><span class="hidden-sm hidden-xs">Nuoroda į <em>YouTube</em> vaizdo įrašą.</span> Bus rodomas po anketos aprašymu.</span>

						<?php echo e($errors->first('video', '<br><label class="control-label">:message</label>')); ?>

					</div>
				</div>
			</div>
		</div>

		<div class="pull-right hidden-sm hidden-xs" style="margin-bottom: 100px;">
			<button type="submit" class="btn btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Išsaugoti duomenis</button>
		</div>

		<div class="visible-sm visible-xs">
			<hr>

			<button type="submit" class="btn btn-block btn-lg btn-primary"><span class="glyphicon glyphicon-floppy-disk"></span> Išsaugoti duomenis</button>
		</div>

		<p></p>
	<?php echo e(Form::close()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>