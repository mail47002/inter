<?php echo $__env->make('frontend.layouts.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('title'); ?>Prisijungimas - <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-sm-8 col-sm-offset-2">
			<div class="page-header">
				<h1>Prisijungimas</h1>
			</div>

			<?php if(session('login_error')): ?>
				<div class="alert alert-danger">
					<h4>Klaida!</h4>

					<?php if((int)session('login_error') == 1): ?>
						Prisijungimo duomenys neteisingi.
					<?php endif; ?>
				</div>
			<?php endif; ?>

			<?php echo e(Form::open([ 'route' => 'login.session', 'class' => 'form-horizontal' ])); ?>

				<div class="form-group">
					<?php echo e(Form::label('email', 'El. paštas', ['class' => 'control-label col-sm-4'])); ?>


					<div class="col-sm-8">
						<?php echo e(Form::email('email', null, ['class' => 'form-control', 'placeholder' => 'El. pašto adresas'])); ?>

					</div>
				</div>

				<div class="form-group">
					<?php echo e(Form::label('password', 'Slaptažodis', ['class' => 'control-label col-sm-4'])); ?>


					<div class="col-sm-8">
						<?php echo e(Form::password('password', ['class' => 'form-control', 'placeholder' => 'Slaptažodis prisijungimui'])); ?>

					</div>
				</div>

				<div class="form-group">
					<div class="col-sm-8 col-sm-offset-4">
						<button class="btn btn-success">Jungtis</button>
						<a href="<?php echo e(route('login.registration')); ?>" class="btn btn-default">Registruotis</a>
						<a href="<?php echo e(route('password.remind')); ?>" class="btn btn-default">Priminti slaptažodį</a>
					</div>
				</div>

				<hr>

				<div class="form-group text-center">
					<div class="col-sm-12">
						<a href="<?php echo e(route('login.register_facebook')); ?>" class="btn btn-link"><img src="<?php echo e(asset('images/facebook.png')); ?>" alt=""></a>
						<a href="<?php echo e(route('login.register_google')); ?>" class="btn btn-link"><img src="<?php echo e(asset('images/googlep.png')); ?>" alt=""></a>
					</div>
				</div>
			<?php echo e(Form::close()); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>