<?php echo $__env->make('frontend.layouts.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('title'); ?>Pradinis - <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="jumbotron text-center">
		<h1>
			Apklausos internetu
		</h1>

		<p>
			Lorem ipsum dolor sit amet, consectetur adipisicing elit. Dolor consequuntur perferendis nisi molestias, dolores 
			provident vel eos tenetur aperiam debitis, cupiditate tempora. Incidunt, cumque reprehenderit nostrum fugit unde, 
			consequuntur rerum aperiam dolor molestias vel nulla. Officiis rerum libero ratione laudantium, voluptate excepturi. 
			Sit, atque commodi sint distinctio ratione rem temporibus.
		</p>

		<br>

		<p>
			<a href="<?php echo e(route('campaigns.create')); ?>" class="btn btn-lg btn-success">Sukurk anketą</a>
		</p>
	</div>
	
	<div class="row">
		<div class="col-sm-12">
			<p class="lead">Rekomenduojamos anketos</p>

			<?php if(count($entries) > 0): ?>
				<?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<h4>
						<a href="<?php echo e(route('campaigns.answer', $entry->id)); ?>"><?php echo e($entry->title); ?></a>

						<div style="width: 100%; overflow: hidden; white-space: nowrap;">
							<small title="<?php echo e($entry->description); ?>"><?php echo e($entry->description); ?></small>
						</div>
					</h4>

					<?php if($auth_check && $entry->advertise_results): ?>
						<div class="btn btn-xs btn-success" title="Uždarbis">
							<span class="glyphicon glyphicon-usd"></span>
							<?php echo e($entry->questions()->count() * 2); ?>

						</div>
					<?php endif; ?>
					
					<a href="<?php echo e(route('campaigns.answers', $entry->id)); ?>" class="btn btn-xs btn-default">
						<span class="glyphicon glyphicon-tasks"></span>
						<?php echo e(count($entry->results)); ?>

					</a>

					<a href="#" class="btn btn-xs btn-default">
						<span class="glyphicon glyphicon-user"></span>
						<?php echo e($entry->user->username); ?>

					</a>

					<a href="#" class="btn btn-xs btn-default">
						<span class="glyphicon glyphicon-calendar"></span>
						<?php echo e($entry->created_at); ?>

					</a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
				<div class="alert alert-warning">
					Anketų nėra.
				</div>
			<?php endif; ?>

			<hr>

			<p class="lead">Naujausios viešos anketos</p>

			<?php if(count($public_entries) > 0): ?>
				<?php $__currentLoopData = $public_entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<h4>
						<a href="<?php echo e(route('campaigns.answer', $entry->id)); ?>"><?php echo e($entry->title); ?></a>

						<div style="width: 100%; overflow: hidden; white-space: nowrap;">
							<small title="<?php echo e($entry->description); ?>"><?php echo e($entry->description); ?></small>
						</div>
					</h4>

					<?php if($auth_check && $entry->advertise_results): ?>
						<div class="btn btn-xs btn-success" title="Uždarbis">
							<span class="glyphicon glyphicon-usd"></span>
							<?php echo e($entry->questions()->count() * 2); ?>

						</div>
					<?php endif; ?>
					
					<a href="<?php echo e(route('campaigns.answers', $entry->id)); ?>" class="btn btn-xs btn-default">
						<span class="glyphicon glyphicon-tasks"></span>
						<?php echo e(count($entry->results)); ?>

					</a>

					<a href="#" class="btn btn-xs btn-default">
						<span class="glyphicon glyphicon-user"></span>
						<?php echo e($entry->user->username); ?>

					</a>

					<a href="#" class="btn btn-xs btn-default">
						<span class="glyphicon glyphicon-calendar"></span>
						<?php echo e($entry->created_at); ?>

					</a>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
				<div class="alert alert-warning">
					Anketų nėra.
				</div>
			<?php endif; ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>