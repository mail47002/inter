<?php echo $__env->make('frontend.layouts.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('title'); ?>Priminti slaptažodį - <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="page-header">
		<h1>
			Priminti slaptažodį
		</h1>
	</div>

	<?php if(Session::has('error')): ?>
		<div class="alert alert-danger">
			Klaida, vartotojas tokiu el. pašto adresu neegzistuoja.
		</div>
	<?php elseif(Session::has('status')): ?>
		<div class="alert alert-success">
			Instrukcija sėkmingai išsiųsta nurodytu el. paštu.
		</div>
	<?php endif; ?>

	<form action="<?php echo e(route('password.remind.post')); ?>" method="POST" class="form-horizontal">
		<div class="form-group <?php echo e(( $errors->first('email') ? 'has-error' : NULL)); ?>">
			<?php echo e(Form::label('email', 'El. paštas', [ 'class' => 'col-sm-3 control-label'])); ?>


			<div class="col-sm-9">
				<?php echo e(Form::email('email', null, [ 'class' => 'form-control', 'placeholder' => 'El. pašto adresas'])); ?>


				<?php echo e($errors->first('email', '<label class="control-label">:message</label>')); ?>

			</div>
		</div>

		<div class="form-group">
			<div class="col-sm-9 col-sm-offset-3">
				<button class="btn btn-primary">Patvirtinti</button>
			</div>
		</div>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>