<?php echo $__env->make('frontend.layouts.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('title'); ?>Anketos „<?php echo e($entry->title); ?>“ rezultatai - <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript" src="<?php echo e(asset('Frontend')); ?>"></script>
	<script type="text/javascript" src="https://www.google.com/jsapi"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="page-header">
		<h1>
			<?php echo e($entry->title); ?>

			<small>Anketos rezultatai</small>
		</h1>
	</div>

	<?php echo $__env->make('frontend.campaigns.tabs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<?php if(count($bad_results) > 1): ?>
		<div class="alert alert-info">
			<h4>Rezultatai filtruojami pagal šiuos atsakymus:</h4>
			
			<?php $__currentLoopData = json_decode(Input::get('questions')); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question => $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<strong><?php echo e(CampaignQuestion::find($question)->title); ?></strong> -> <?php echo e(CampaignQuestionOption::find($option)->title); ?><br>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	<?php endif; ?>

	<div class="row">
		<?php if(count($entry->results)): ?>
			<div class="col-sm-9">
				<?php if(count($entry->questions()->whereNotIn('id', $bad_questions)->get())): ?>
					<?php $__currentLoopData = $entry->questions()->whereNotIn('id', $bad_questions)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<p class="lead">
							<?php echo e($question->title); ?>

							<?php echo e($errors->first($question->id, '<small><label class="control-label">:message</label></small>')); ?>

						</p>

						<?php if($question->photo): ?>
							<p>
								<img src="<?php echo e(asset($question->photo)); ?>" alt="<?php echo e($question->title); ?>" class="img-thumbnail">
							</p>
						<?php endif; ?>

						<?php if(in_array($question->type, ['radio', 'select', 'check'])): ?>
							<div id="chart-<?php echo e($question->id); ?>" class="col-sm-12" style="height: 250px;"></div>

							<script type="text/javascript">
								google.load("visualization", "1", {packages:["corechart"]});
								google.setOnLoadCallback(drawChart);

								function drawChart() {
									var data = google.visualization.arrayToDataTable([
										['Option', 'Count'],
										<?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											['<?php echo e($option->title); ?>', <?php echo e($question->answers()->whereNotIn('result_id', $bad_results)->where('option_id', '=', $option->id)->count()); ?>],
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										['Kitas variantas', <?php echo e($question->answers()->whereNotIn('result_id', $bad_results)->where('type', '=', 'custom')->count()); ?>],
									]);

									var chart = new google.visualization.PieChart(document.getElementById('chart-<?php echo e($question->id); ?>'));

									chart.draw(data);
								}
							</script>

							<div class="clearfix"></div>

							<?php if($question->answers()->whereNotIn('result_id', $bad_results)->where('type', '=', 'custom')->count()): ?>
								<div class="label label-primary">Kiti variantai</div><br>

								<?php $__currentLoopData = $question->answers()->whereNotIn('result_id', $bad_results)->where('type', '=', 'custom')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $custom_answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="label label-default"><?php echo e($custom_answer->value); ?></div><br>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							<?php endif; ?>
						<?php elseif($question->type == 'matrix'): ?>
							<div id="chart-<?php echo e($question->id); ?>" class="col-sm-12" style="height: 350px;"></div>

							<script type="text/javascript">
								google.load("visualization", "1", {packages:["corechart"]});
								google.setOnLoadCallback(drawChart);

								function drawChart() {
									var data = google.visualization.arrayToDataTable([
										[
											'Option_x',

											<?php $__currentLoopData = $question->options()->where('matrix', '=', 'x')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option_x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												'<?php echo e($option_x->title); ?>',
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

											{ role: 'annotation' }
										],

										<?php $__currentLoopData = $question->options()->where('matrix', '=', 'y')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option_y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											[
												'<?php echo e($option_y->title); ?>',

												<?php $__currentLoopData = $question->options()->where('matrix', '=', 'x')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option_x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php echo e($question->answers()->whereNotIn('result_id', $bad_results)->where('option_id', '=', $option_y->id)->where('value', '=', $option_x->id)->count()); ?>,
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

												'',
											],
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									]);

									var options = {
									legend: { position: 'top' },
									bar: { groupWidth: '75%' },
									isStacked: true
									};

									var chart = new google.visualization.BarChart(document.getElementById('chart-<?php echo e($question->id); ?>'));

									chart.draw(data, options);
								}
							</script>
						<?php elseif(in_array($question->type, ['string', 'text'])): ?>
							<?php $__currentLoopData = $question->answers()->whereNotIn('result_id', $bad_results)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="label label-default"><?php echo e($answer->value); ?></div><br>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>

						<hr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					<div class="alert alert-warning">
						Klausimų nėra.
					</div>
				<?php endif; ?>
			</div>

			<div class="col-sm-3">
				<div class="well">
					<p class="lead">Anketos meniu</p>

					<div class="list-group">
						<a href="<?php echo e(route('campaigns.results.xlsx', $entry->id)); ?>" class="list-group-item">Eksportuoti į Excel</a>
					</div>
				</div>
		
				<div class="well">
					<p class="lead">Statistinė analizė</p>

					<div class="list-group">
						<a href="#" data-toggle="modal" data-target="#duomenu-aprasymas" class="list-group-item">Duomenų aprašymas</a>
						<a href="#" data-toggle="modal" data-target="#poriniai-stebejimai" class="list-group-item">Poriniai stebėjimai</a>
						<a href="#" data-toggle="modal" data-target="#koreliacine-analize" class="list-group-item">Koreliacinė analizė</a>
						<a href="#" data-toggle="modal" data-target="#regresine-analize" class="list-group-item">Regresinė analizė</a>
					</div>
				</div>
			</div>

			<div class="modal fade" id="duomenu-aprasymas" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Uždaryti</span></button>
							<h4 class="modal-title" id="myModalLabel">Duomenų aprašymas</h4>
						</div>

						<div class="modal-body">
							<?php $__currentLoopData = $entry->questions()->where('type', '=', 'radio')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<div class="row">
									<div class="col-sm-12">
										<strong><?php echo e($question->title); ?></strong>
									</div>
								</div>
								
								<?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="row">
										<div class="col-sm-11 col-sm-offset-1">
											<div class="checkbox">
												<label>
													<input type="radio" class="filter-1-radio" name="<?php echo e($question->id); ?>" value="<?php echo e($option->id); ?>"> <?php echo e($option->title); ?>

												</label>
											</div>
										</div>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								<p></p>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>

						<script type="text/javascript">
							var prefix 	= '<?php echo e(route('campaigns.results', $entry->id)); ?>';
							var postfix = '?filter=1&questions=';

							$(document).on('change', '.filter-1-radio', function()
							{
								var ending = {};

								$(".filter-1-radio:checked").each(function ()
								{
									ending[ $(this).attr('name') ] = $(this).val();
								});

								ending = JSON.stringify(ending);

								$("#filter-url").attr('href', prefix + postfix + ending);
							});

							$(document).ready(function ()
							{
								$("#filter-url").attr('href', prefix);
							});
						</script>
						
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Uždaryti</button>
							<a href="" id="filter-url" class="btn btn-primary">Filtruoti</a>
						</div>
					</div>
				</div>
			</div>

			<div class="modal fade" id="poriniai-stebejimai" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Uždaryti</span></button>
							<h4 class="modal-title" id="myModalLabel">Poriniai stebėjimai</h4>
						</div>
						
						<?php echo e(Form::open( ['route' => ['campaigns.cross_tabulation', $entry->id], 'class' => 'form-horizontal'] )); ?>

							<div class="modal-body">
								<p class="lead">Pirmas klausimas</p>

								<?php $__currentLoopData = $entry->questions()->where('type', '<>', 'matrix')->where('type', '<>', 'string')->where('type', '<>', 'text')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="checkbox">
										<label>
											<input type="radio" name="question_first" value="<?php echo e($question->id); ?>"> <?php echo e($question->title); ?>

										</label>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								<hr>

								<p class="lead">Antras klausimas</p>

								<?php $__currentLoopData = $entry->questions()->where('type', '<>', 'matrix')->where('type', '<>', 'string')->where('type', '<>', 'text')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="checkbox">
										<label>
											<input type="radio" name="question_second" value="<?php echo e($question->id); ?>"> <?php echo e($question->title); ?>

										</label>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Uždaryti</button>
								<button class="btn btn-primary">Analizuoti</button>
							</div>
						<?php echo e(Form::close()); ?>

					</div>
				</div>
			</div>

			<div class="modal fade" id="koreliacine-analize" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Uždaryti</span></button>
							<h4 class="modal-title" id="myModalLabel">Koreliacinė analizė</h4>
						</div>
						
						<?php echo e(Form::open( ['route' => ['campaigns.correlation', $entry->id], 'class' => 'form-horizontal'] )); ?>

							<div class="modal-body">
								<p class="lead">Pasirinkite klausimus</p>

								<?php $__currentLoopData = $entry->questions()->whereIn('type', ['radio', 'select', 'check', 'matrix'])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="checkbox">
										<label>
											<input type="checkbox" name="questions[]" value="<?php echo e($question->id); ?>"> <?php echo e($question->title); ?>

										</label>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Uždaryti</button>
								<button class="btn btn-primary">Analizuoti</button>
							</div>
						<?php echo e(Form::close()); ?>

					</div>
				</div>
			</div>

			<div class="modal fade" id="regresine-analize" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Uždaryti</span></button>
							<h4 class="modal-title" id="myModalLabel">Regresinė analizė</h4>
						</div>
						
						<?php echo e(Form::open( ['route' => ['campaigns.regression', $entry->id], 'class' => 'form-horizontal'] )); ?>

							<div class="modal-body">
								<p class="lead">Pasirinkite klausimus</p>

								<?php $__currentLoopData = $entry->questions()->whereIn('type', ['radio', 'select'])->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<div class="checkbox">
										<label>
											<input type="checkbox" name="questions[]" value="<?php echo e($question->id); ?>"> <?php echo e($question->title); ?>

										</label>
									</div>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
							
							<div class="modal-footer">
								<button type="button" class="btn btn-default" data-dismiss="modal">Uždaryti</button>
								<button class="btn btn-primary">Analizuoti</button>
							</div>
						<?php echo e(Form::close()); ?>

					</div>
				</div>
			</div>
		<?php else: ?>
			<div class="col-sm-12">
				<div class="alert alert-warning">
					Kol kas niekas neužpildė šios anketos.
				</div>
			</div>
		<?php endif; ?>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>