<?php echo $__env->make('frontend.layouts.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('title'); ?>Mano kreditai - <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="page-header">
		<h1>Mano kreditai</h1>
	</div>

	<div class="row">
		<div class="col-sm-5">
			<h3>Apie kreditus</h3>

			<p>
				Lorem ipsum dolor sit amet, consectetur adipisicing elit. Optio sit, esse perspiciatis ullam aut eveniet rerum modi blanditiis inventore vero ad sed incidunt tempora quis fugiat, ab cum voluptatibus facilis. Voluptatem officiis molestias odio, debitis dolore itaque rerum, odit! Quas, in! Harum sapiente expedita fugit quaerat ipsa laborum quas minima dolorum repellat ad, in rerum, soluta. Ducimus et neque adipisci, perferendis, distinctio provident vero veritatis numquam esse commodi quasi facere quos maxime fugiat quo accusamus voluptatum a qui? Veritatis magnam itaque nisi atque facilis officia laudantium, consequuntur nostrum esse. Repellendus deserunt a asperiores ipsum! Accusantium fugiat fuga dolore incidunt neque.
			</p>

			<h3>Pirkti internetu</h3>

			<table class="table table-condensed table-striped">
				<thead>
					<th>Kaina</th>
					<th>Kreditų kiekis</th>
					<th></th>
				</thead>

				<?php $__currentLoopData = $prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $price): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td style="vertical-align: middle;"><?php echo e($price['ammount']); ?>,00 Lt</td>
						<td style="vertical-align: middle;"><?php echo e(number_format($price['credits'], 0, ',', ' ')); ?></td>
						<td>
							<a href="<?php echo e(route('payments.create', [ $price['ammount'] ])); ?>" class="btn btn-primary btn-sm">Pirkti internetu</a>
						</td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>

		<div class="col-sm-7">
			<h3>Kreditų likutis</h3>

			<button class="btn btn-default">
				<?php echo e(auth()->user()->credits()->sum('credits')); ?>

				<br>
				<small>Viso kreditų</small>
			</button>

			<button class="btn <?php echo e(auth()->user()->credits()->sum('credits') - auth()->user()->campaigns()->sum('advertise_credits') > 0 ? 'btn-success' : 'btn-default'); ?>">
				<?php echo e(auth()->user()->credits()->sum('credits') - auth()->user()->campaigns()->sum('advertise_credits')); ?>

				<br>
				<small>Laisvų kreditų</small>
			</button>

			<a href="<?php echo e(route('campaigns.my')); ?>" class="btn <?php echo e(auth()->user()->campaigns()->sum('advertise_credits') > 0 ? 'btn-warning' : 'btn-default'); ?>">
				<?php echo e(auth()->user()->campaigns()->sum('advertise_credits')); ?>

				<br>
				<small>Anketoms priskirtų kreditų</small>
			</a>
			
			<h3>Kreditų istorija</h3>

			<table class="table table-condensed">
				<thead>
					<th>Data</th>
					<th>Šaltinis</th>
					<th>Kreditai</th>
				</thead>

				<?php $__currentLoopData = auth()->user()->credits()->orderBy('id', 'desc')->take(10)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr class="<?php echo e($entry->credits >= 0 ? 'success' : 'danger'); ?>">
						<td><?php echo e($entry->created_at); ?></td>
						<td><?php echo e($entry->description); ?></td>
						<td><?php echo e($entry->credits); ?></td>
					</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</table>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>