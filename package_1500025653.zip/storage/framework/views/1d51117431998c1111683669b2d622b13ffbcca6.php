<?php echo $__env->make('frontend.layouts.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('title'); ?>Prisijungimas - <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="row">
		<div class="col-sm-12">
			<div class="page-header">
				<h1>Registracija</h1>
			</div>

			<?php echo e(Form::open([ 'route' => 'login.register', 'class' => 'form-horizontal' ])); ?>

				<div class="form-group <?php echo e(( $errors->first('r_email') ? 'has-error' : NULL)); ?>">
					<?php echo e(Form::label('r_email', 'El. paštas', ['class' => 'control-label col-sm-3'])); ?>


					<div class="col-sm-9">
						<?php echo e(Form::email('r_email', '', ['class' => 'form-control', 'placeholder' => 'El. pašto adresas'])); ?>

						<span class="label label-info">Nebus rodomas. Bus naudojamas prisijungimui.</span>
						
						<?php echo e($errors->first('r_email', '<br><label class="control-label">:message</label>')); ?>

					</div>
				</div>

				<div class="form-group <?php echo e(( $errors->first('r_username') ? 'has-error' : NULL)); ?>">
					<?php echo e(Form::label('r_username', 'Vartotojas', ['class' => 'control-label col-sm-3'])); ?>


					<div class="col-sm-9">
						<?php echo e(Form::text('r_username', '', ['class' => 'form-control', 'placeholder' => 'Vartotojo vardas'])); ?>

						<span class="label label-info">Bus rodomas kartu su jūsų anketomis</span>

						<?php echo e($errors->first('r_username', '<br><label class="control-label">:message</label>')); ?>

					</div>
				</div>

				<div class="form-group <?php echo e(( $errors->first('r_password') || $errors->first('r_password_confirmation') ? 'has-error' : NULL)); ?>">
					<?php echo e(Form::label('r_password', 'Slaptažodis', ['class' => 'control-label col-sm-3'])); ?>

	
					<div class="col-sm-9">
						<div class="row">
							<div class="col-sm-6">
								<?php echo e(Form::password('r_password', ['class' => 'form-control', 'placeholder' => 'Sugalvokite slaptažodį'])); ?>


								<?php echo e($errors->first('r_password', '<label class="control-label">:message</label>')); ?>

							</div>

							<div class="col-sm-6">
								<?php echo e(Form::password('r_password_confirmation', ['class' => 'form-control', 'placeholder' => 'Pakartokite slaptažodį'])); ?>


								<?php echo e($errors->first('r_password_confirmation', '<label class="control-label">:message</label>')); ?>

							</div>
						</div>
					</div>
				</div>

				<div class="form-group">
					<div class="col-sm-9 col-sm-offset-3">
						<button class="btn btn-primary btn-lg">Registruotis</button>
					</div>
				</div>
			<?php echo e(Form::close()); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>