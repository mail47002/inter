<?php echo $__env->make('frontend.layouts.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('title'); ?>Anketos „<?php echo e($entry->title); ?>“ klausimai - <?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<script type="text/javascript" src="<?php echo e(asset('Frontend')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="page-header">
		<h1>
			<?php echo e($entry->title); ?>

			<small>Anketos klausimai</small>
		</h1>
	</div>

	<?php echo $__env->make('frontend.campaigns.tabs', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

	<div class="row">
		<div class="col-sm-8">
			<?php if(count($entry->results)): ?>
				<div class="alert alert-danger">
					<h4>Klausimų redaguoti negalima!</h4>

					<p>
						Jūsų anketa turi atsakymų, todėl klausimų koreguoti negalima.
					</p>

					<p>
						<a href="<?php echo e(route('campaigns.deactivate', $entry->id)); ?>" class="btn btn-danger">Ištrinti rezultatus ir deaktyvuoti anketą</a>
					</p>
				</div>
			<?php elseif($entry->active): ?>
				<div class="alert alert-danger">
					<h4>Klausimų redaguoti negalima!</h4>

					<p>
						Jūsų anketa yra pažymėta kaip <strong>aktyvi</strong>, todėl klausimų koreguoti negalima.
					</p>

					<p>
						<a href="<?php echo e(route('campaigns.deactivate', $entry->id)); ?>" class="btn btn-danger">Deaktyvuoti anketą</a>
					</p>
				</div>
			<?php endif; ?>

			<?php if(count($entry->questions)): ?>
				<?php $__currentLoopData = $entry->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class="panel panel-default">
						<div class="panel-body">
							<p class="lead">
								<?php echo e($question->title); ?>


								<span class="pull-right">
									<?php if($entry->active == 0): ?>
										<span class="btn-group btn-group-sm">
											<a href="<?php echo e(route('campaigns.questions.edit', [$entry->id, $question->id])); ?>" class="btn btn-default"><span class="glyphicon glyphicon-edit"></span> Redaguoti</a>
											<a href="<?php echo e(route('campaigns.questions.destroy', [$entry->id, $question->id])); ?>" class="btn btn-default"><span class="glyphicon glyphicon-trash"></span> Ištrinti</a>
										</span>
									<?php endif; ?>
								</span>
							</p>

							<?php if($question->photo): ?>
								<p>
									<img src="<?php echo e(asset($question->photo)); ?>" alt="<?php echo e($question->title); ?>" class="img-thumbnail">
								</p>
							<?php endif; ?>
							
							<?php if($question->type == 'radio'): ?>
								<?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<input disabled type="radio" name="question-<?php echo e($question->id); ?>"> <?php echo e($option->title); ?><br>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								<?php if($question->custom_answer): ?>
									<div class="form-inline">
										<input disabled type="radio" name="question-<?php echo e($question->id); ?>"> <input disabled type="text" class="form-control" placeholder="Kitas variantas"><br>
									</div>
								<?php endif; ?>
							<?php elseif($question->type == 'select'): ?>
								<select disabled>
									<?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<option><?php echo e($option->title); ?></option>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</select>
							<?php elseif($question->type == 'check'): ?>
								<?php $__currentLoopData = $question->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<input disabled type="checkbox" name="question-<?php echo e($question->id); ?>"> <?php echo e($option->title); ?><br>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

								<?php if($question->custom_answer): ?>
									<div class="form-inline">
										<input disabled type="checkbox" name="question-<?php echo e($question->id); ?>"> <input disabled type="text" class="form-control" placeholder="Kitas variantas"><br>
									</div>
								<?php endif; ?>
							<?php elseif($question->type == 'string'): ?>
								<input disabled type="text" class="form-control" placeholder="">
							<?php elseif($question->type == 'text'): ?>
								<textarea disabled name="" id="" cols="30" rows="10" class="form-control"></textarea>
							<?php elseif($question->type == 'matrix'): ?>
								<table class="table table-condensed table-bordered">
									<tr>
										<th class="active"></th>

										<?php $__currentLoopData = $question->options()->where('matrix', '=', 'x')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option_x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<th class="text-center active"><?php echo e($option_x->title); ?></th>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tr>

									<?php $__currentLoopData = $question->options()->where('matrix', '=', 'y')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option_y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<th class="text-center active"><?php echo e($option_y->title); ?></th>

											<?php $__currentLoopData = $question->options()->where('matrix', '=', 'x')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option_x): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<td class="text-center">
													<input type="radio" disabled name="question-<?php echo e($option_y->id); ?>" value="<?php echo e($option_x->id); ?>">
												</td>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</table>
							<?php endif; ?>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			<?php else: ?>
				<div class="alert alert-warning">
					Klausimų nėra.
				</div>
			<?php endif; ?>
		</div>

		<div class="col-sm-4">
			<?php if($entry->active == 0): ?>
				<div class="well">
					<p class="lead">Pridėti klausimą</p>

					<div class="list-group">
						<a href="<?php echo e(route('campaigns.questions.add', [$entry->id, 'radio'])); ?>" class="list-group-item">Vieno varianto pasirinkimas</a>
						<a href="<?php echo e(route('campaigns.questions.add', [$entry->id, 'select'])); ?>" class="list-group-item">Iškrentantis atsakymų sąrašas</a>
						<a href="<?php echo e(route('campaigns.questions.add', [$entry->id, 'check'])); ?>" class="list-group-item">Kelių variantų pasirinkimas</a>
						<a href="<?php echo e(route('campaigns.questions.add', [$entry->id, 'string'])); ?>" class="list-group-item">Eilutė teksto įvedimui</a>
						<a href="<?php echo e(route('campaigns.questions.add', [$entry->id, 'text'])); ?>" class="list-group-item">Langelis teksto įvedimui</a>
						<a href="<?php echo e(route('campaigns.questions.add', [$entry->id, 'matrix'])); ?>" class="list-group-item">Matrica</a>
					</div>
				</div>
			<?php endif; ?>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>