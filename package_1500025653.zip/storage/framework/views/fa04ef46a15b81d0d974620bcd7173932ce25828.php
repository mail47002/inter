<?php echo $__env->make('frontend.layouts.navigation', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->startSection('title'); ?>Anketų sąrašas - <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="page-header">
		<h1>
			Anketų sąrašas
		</h1>
	</div>
	
	<?php if(count($entries) > 0): ?>
		<?php $__currentLoopData = $entries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<div class="panel panel-default">
				<div class="panel-body">
					<h4>
						<a href="<?php echo e(route('campaigns.answer', $entry->id)); ?>">
							<img src="<?php echo e($entry->user->photo ? $entry->user->photo : 'holder.js/32x32/text:&nbsp;'); ?>" alt="<?php echo e($entry->user->username); ?>" style="height: 32px" class="img-circle">
							
							<?php echo e($entry->title); ?>

						</a>

						<div style="width: 100%; overflow: hidden; white-space: nowrap;">
							<small title="<?php echo e($entry->description); ?>"><?php echo e($entry->description); ?></small>
						</div>
					</h4>
	
					<?php if($auth_check && $entry->advertise_results): ?>
						<div class="btn btn-sm btn-success" title="Uždarbis">
							<span class="glyphicon glyphicon-usd"></span>
							<?php echo e($entry->questions()->count() * 2); ?>

						</div>
					<?php endif; ?>
					
					<a href="<?php echo e(route('campaigns.answers', $entry->id)); ?>" class="btn btn-sm btn-default">
						<span class="glyphicon glyphicon-tasks"></span>
						<?php echo e(count($entry->results)); ?>

					</a>

					<a href="#" class="btn btn-sm btn-default">
						<span class="glyphicon glyphicon-user"></span>
						<?php echo e($entry->user->username); ?>

					</a>

					<a href="#" class="btn btn-sm btn-default">
						<span class="glyphicon glyphicon-calendar"></span>
						<?php echo e($entry->created_at); ?>

					</a>
				</div>
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<div class="text-center">
			<?php echo e($entries->links()); ?>

		</div>
	<?php else: ?>
		<div class="alert alert-warning">
			Anketų nėra.
		</div>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>