<?php

return [
	'facebook' 	=> 1,
	'google' 	=> 2,
];