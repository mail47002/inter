<?php

return [
	'admin' => 1,
	'user' 	=> 0
];