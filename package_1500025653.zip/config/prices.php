<?php

return [
    ['ammount' => 5, 'credits' => 4000],
    ['ammount' => 10, 'credits' => 10000],
    ['ammount' => 15, 'credits' => 20000],
];