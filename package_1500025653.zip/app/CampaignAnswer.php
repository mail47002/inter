<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CampaignAnswer extends Model
{
    protected $table = 'campaigns_answers';
}
