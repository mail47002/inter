<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CampaignTag extends Model
{
    protected $table = 'campaigns_tags';
}
