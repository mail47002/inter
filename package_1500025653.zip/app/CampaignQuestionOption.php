<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CampaignQuestionOption extends Model
{
    protected $table = 'campaigns_questions_options';
}
